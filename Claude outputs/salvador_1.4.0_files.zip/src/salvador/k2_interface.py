"""Everything that talks to K2: running it (in-process), synthetic spectra (autok), equivalent widths
and slopes of the curve of growth (eqw_k2), trimmed linelists, abundance-variation (DELTA) files and
the names of the synthetic spectra. The switches K2_IN_PROCESS and TRIM_LINELIST are here.

salvador 1.4.0 needs the version of K2 of November 2026 (or later), whose eqw writes the slope of
the curve of growth in info_ew.txt (5 columns)."""
import importlib
import json
import os
import shutil
import sys
import zlib
from collections import OrderedDict
from pathlib import Path
import numpy as np
import astropy.units as u
from specutils import Spectrum

from .config import BASE_DIR, SYNTH_OUT, WORK_DIR, abu_var_tmp_name, cfg, plt
from .elements import get_element_symbol, strip_ion, symbol_map
from .spectra_io import model_name_codes, read_two_columns


### =============================================================================================
### SPEED: calling K2
### =============================================================================================
### 1) K2 is run inside salvador's Python process. Before, every synthetic spectrum started a new
###    interpreter that re-imported numpy, scipy, astropy, specutils, matplotlib... (~2.5 s per
###    call). k2.main() reads input.k2 exactly as the command 'k2.py' does: same code path, same
###    results. Set K2_IN_PROCESS = False to go back to the external call.
### 2) K2 receives a trimmed linelist for each window. Before, for every synthetic K2 read all
###    the atomic files of linelist.xkur in full (only to check their first and last line) and
###    passed all the molecular files to rmolecasc (~800 MB of reading per synthetic for a few A).
###    Now, once per window, the lines within [w1 - LINELIST_MARGIN_A, w2 + LINELIST_MARGIN_A]
###    are copied into small files in LINELIST_CUT_DIR. Files not sorted in wavelength are
###    passed unchanged (no cut). Set TRIM_LINELIST = False to use linelist.xkur as before.
K2_IN_PROCESS = True
TRIM_LINELIST = True
# 1.4.0: the shortcut K2_FAST_MODEL_CHECK (a wrapper of K2's RunAtlas9.atlas9 that checked whether
# the model atmosphere exists before the ODF interpolation) was removed: K2 now does it itself.
K2_LINELIST = str(BASE_DIR / 'linelist.xkur')
LINELIST_MARGIN_A = 50.0
LINELIST_CUT_DIR = Path('linelist_cut')
LINELIST_INDEX = Path.home() / '.cache' / 'salvador' / 'linelist_index.json'
_WL_WIDTH = {'#ATOMS': 11, '#MOLECULES': 10}     # width of the wavelength field (nm) at line start
_K2_MARKERS = ('#ATOMS', '#MOLECULES', '#TIO', '#H2O', '#PREDICTED')
_k2_module = None
_trim_cache = OrderedDict()


def run_k2():
    """Run K2 on ./input.k2. Returns 0 on success, like os.system('k2.py')."""
    global _k2_module, K2_IN_PROCESS
    if K2_IN_PROCESS and _k2_module is None:
        try:
            exe = shutil.which('k2.py')
            if exe is None:
                raise ImportError('k2.py not found in PATH')
            k2_dir = str(Path(exe).resolve().parent)
            if k2_dir not in sys.path:
                sys.path.insert(0, k2_dir)
            _k2_module = importlib.import_module('k2')
        except Exception as e:
            print(f'Warning: cannot import K2 ({e}). Using the external call k2.py')
            K2_IN_PROCESS = False

    if not K2_IN_PROCESS:
        return os.system('k2.py')

    # K2 may create figures (new ATLAS9 models): no pop-up windows, and close what it leaves open.
    # kgraph.graph_atlas calls plt.close(''), which closes the FIRST figure with an empty label:
    # salvador's open figures get a temporary label during the call so they cannot be closed.
    figs_before = set(plt.get_fignums())
    relabelled = []
    try:
        from matplotlib._pylab_helpers import Gcf
        for manager in Gcf.get_all_fig_managers():
            fig = manager.canvas.figure
            if fig.get_label() == '':
                fig.set_label('_salvador_protected_')
                relabelled.append(fig)
    except Exception:
        pass
    was_interactive = plt.isinteractive()
    plt.ioff()
    try:
        _k2_module.main()
        return 0
    except SystemExit as e:
        if e.code not in (None, 0):
            print(f'Warning: K2 stopped: {e.code}')
            return 1
        return 0
    except Exception as e:
        print(f'Warning: K2 failed: {type(e).__name__}: {e}')
        return 1
    finally:
        for num in set(plt.get_fignums()) - figs_before:
            plt.close(num)
        for fig in relabelled:
            fig.set_label('')
        if was_interactive:
            plt.ion()


def _parse_k2_linelist(path):
    """Sections of a K2 linelist file, read as K2 does (first token of each line):
    [(marker, [file, ...]), ...]. As in K2, the markers are recognised in upper or lower case and
    the other lines starting with '#' are comments (FIX 1.4.0: before, they were taken as files)."""
    sections = []
    with open(path, 'r') as f:
        for row in f:
            tok = row.split()
            if not tok:
                continue
            if tok[0].upper() in _K2_MARKERS:
                sections.append((tok[0].upper(), []))
            elif tok[0].startswith('#'):
                continue
            elif sections:
                sections[-1][1].append(tok[0])
    return sections


def _scan_linelist(path, width):
    """Check once that a linelist file is sorted in wavelength. Returns (sorted, wmin, wmax) in nm.
    A file with unparsable or blank lines (except at the end) counts as not sorted."""
    prev, wmin, blank = -np.inf, np.inf, False
    with open(path, 'rb') as f:
        for row in f:
            if not row.strip():
                blank = True
                continue
            if blank:
                return False, None, None
            try:
                w = float(row[:width])
            except ValueError:
                return False, None, None
            if w < prev:
                return False, None, None
            if w < wmin:
                wmin = w
            prev = w
    return True, float(wmin), float(prev)


def _linelist_record(path, width, index):
    """Sortedness and range of a linelist file, from the index (rebuilt if the file changed)."""
    st = os.stat(path)
    key = os.path.abspath(path)
    rec = index.get(key)
    if rec and rec['size'] == st.st_size and rec['mtime'] == st.st_mtime and rec['width'] == width:
        return rec, False
    if cfg.verbose == 1:
        print(f'Indexing linelist {path} (only once)')
    ok, wmin, wmax = _scan_linelist(path, width)
    rec = {'size': st.st_size, 'mtime': st.st_mtime, 'width': width, 'sorted': ok, 'wmin': wmin, 'wmax': wmax}
    index[key] = rec
    return rec, True


def _line_start_at(f, pos, width):
    """(byte offset, wavelength) of the first line starting at or after byte 'pos'. inf at the end."""
    if pos <= 0:
        f.seek(0)
    else:
        f.seek(pos - 1)
        f.readline()
    start = f.tell()
    row = f.readline()
    if not row.strip():
        return start, np.inf
    return start, float(row[:width])


def _first_offset(f, size, width, condition):
    """Byte offset of the first line whose wavelength satisfies 'condition' (file sorted)."""
    lo, hi = 0, size
    while lo < hi:
        mid = (lo + hi) // 2
        if condition(_line_start_at(f, mid, width)[1]):
            hi = mid
        else:
            lo = mid + 1
    return _line_start_at(f, lo, width)[0]


def _cut_linelist(src, dst, lo_nm, hi_nm, width):
    """Copy the lines of a sorted file with lo_nm <= wavelength <= hi_nm. False if there are none."""
    size = os.path.getsize(src)
    with open(src, 'rb') as f:
        start = _first_offset(f, size, width, lambda w: w >= lo_nm)
        end = _first_offset(f, size, width, lambda w: w > hi_nm)
        if end <= start:
            return False
        f.seek(start)
        data = f.read(end - start)
    with open(dst, 'wb') as g:
        g.write(data)
    return True


def _write_trimmed_linelist(w1, w2):
    """Write the trimmed linelist of the window [w1, w2] (see k2_linelist) and the cut files it
    points to. Returns (path of the linelist file, list of the cut files created)."""
    LINELIST_CUT_DIR.mkdir(exist_ok=True)
    try:
        index = json.loads(LINELIST_INDEX.read_text())
    except (OSError, ValueError):
        index = {}
    changed = False
    lo_nm = (w1 - LINELIST_MARGIN_A) / 10.0
    hi_nm = (w2 + LINELIST_MARGIN_A) / 10.0

    rows, created = [], []
    for marker, files in _parse_k2_linelist(K2_LINELIST):
        rows.append(marker)
        width = _WL_WIDTH.get(marker)
        for src in files:
            if width is None or not os.path.isfile(src) or os.path.getsize(src) == 0:
                rows.append(src)            # left to K2 exactly as before
                continue
            rec, new = _linelist_record(src, width, index)
            changed = changed or new
            if not rec['sorted']:
                rows.append(src)            # cannot cut safely: full file
                continue
            if rec['wmax'] < lo_nm or rec['wmin'] > hi_nm:
                continue                    # no lines near the window
            dst = LINELIST_CUT_DIR / f"{Path(src).stem}_{w1}_{w2}{Path(src).suffix}"
            if _cut_linelist(src, dst, lo_nm, hi_nm, width):
                rows.append(str(dst.resolve()))
                created.append(dst)

    if changed:
        LINELIST_INDEX.parent.mkdir(parents=True, exist_ok=True)
        tmp_index = LINELIST_INDEX.with_suffix(f'.{os.getpid()}.tmp')
        tmp_index.write_text(json.dumps(index, indent=1))
        os.replace(tmp_index, LINELIST_INDEX)       # atomic: safe with parallel workers

    out = (LINELIST_CUT_DIR / f"linelist_{w1}_{w2}.xkur").resolve()
    out.write_text('\n'.join(rows) + '\n')
    return str(out), created


def k2_linelist(w1, w2):
    """Linelist file to pass to K2 for the window [w1, w2] (A). The last 3 windows are kept."""
    if not TRIM_LINELIST:
        return K2_LINELIST
    key = (int(w1), int(w2))
    if key in _trim_cache:
        _trim_cache.move_to_end(key)
        return _trim_cache[key][0]
    try:
        out, created = _write_trimmed_linelist(*key)
    except Exception as e:
        print(f'Warning: linelist trimming failed ({type(e).__name__}: {e}). Using {K2_LINELIST}')
        return K2_LINELIST
    _trim_cache[key] = (out, created)
    while len(_trim_cache) > 3:
        _, (old_out, old_created) = _trim_cache.popitem(last=False)
        for p in [Path(old_out)] + old_created:
            try:
                p.unlink()
            except OSError:
                pass
    return out


LINELIST_RECORD = SYNTH_OUT / 'linelists.json'     # linelists used for the synthetics of synth_out/


def linelist_fingerprint() -> dict | None:
    """linelist.xkur (its text) and the size and modification time of each file it lists; None if
    there is no linelist.xkur."""
    if not os.path.isfile(K2_LINELIST):
        return None
    files = {}
    for _, names in _parse_k2_linelist(K2_LINELIST):
        for name in names:
            try:
                st = os.stat(name)
                files[name] = [st.st_size, st.st_mtime]
            except OSError:
                files[name] = None
    return {'linelist.xkur': Path(K2_LINELIST).read_text(), 'files': files}


def check_synth_out_linelists() -> bool:
    """NEW: warn if linelist.xkur, or a linelist it lists, changed since the synthetic spectra of
    synth_out/ were computed: their names do not depend on the linelists, so they would be reused.
    The linelists are recorded in synth_out/linelists.json when synth_out/ has no synthetic yet (or
    no record, e.g. synthetics of a previous version). Returns True if they changed."""
    current = linelist_fingerprint()
    if current is None:
        return False
    try:
        recorded = json.loads(LINELIST_RECORD.read_text())
    except (OSError, ValueError):
        recorded = None
    has_spectra = SYNTH_OUT.is_dir() and any(SYNTH_OUT.glob('*.nb'))
    if recorded is None or not has_spectra:
        SYNTH_OUT.mkdir(parents=True, exist_ok=True)
        LINELIST_RECORD.write_text(json.dumps(current, indent=1))
        return False
    if recorded == current:
        return False
    changed = sorted(n for n in set(recorded.get('files', {})) | set(current['files'])
                     if recorded.get('files', {}).get(n) != current['files'].get(n))
    if recorded.get('linelist.xkur') != current['linelist.xkur']:
        changed.insert(0, 'linelist.xkur')
    shown = ', '.join(changed[:5]) + (f' and {len(changed) - 5} more' if len(changed) > 5 else '')
    print(f"WARNING: the linelists changed since the synthetic spectra in {SYNTH_OUT.name}/ were computed ({shown}). "
          f"The synthetics already there are used as they are: to compute them with the new linelists, move or "
          f"delete {SYNTH_OUT.name}/ (this warning is repeated until then).")
    return True


def cleanup_linelist_cut():
    """Remove the trimmed linelists (end of run)."""
    _trim_cache.clear()
    if LINELIST_CUT_DIR.is_dir():
        shutil.rmtree(LINELIST_CUT_DIR, ignore_errors=True)

def add_delta_entry(type_abu, abu_var, zcode, var):
    """Add to the abundance-variation file passed to K2 the entry of the line: DELTA (abundance),
    GF (log gf) or ISOR (isotopic ratio) for the element zcode, with the value var."""
    filename = abu_var
    abu_str = f"{var:.2f}"

    if type_abu in ['ABU', 'ABU2', 'MOLEC', 'ROTAT', 'ABUF']:
        new_entry = f"DELTA {zcode} {abu_str}\n"
    elif type_abu == 'ABU_GF':
        new_entry = f"GF {zcode} {abu_str}\n"
    elif type_abu == 'ISOR':
        abu_str = f"{var:.0f}"
        new_entry = f"ISOR {zcode} {abu_str}\n"
    else:
        return # Leave the function if the keyword is not recognized

    # Whether a newline is needed before the new entry
    add_newline = False

    # --- CHECK OF THE FILE ---
    if os.path.exists(filename):
        with open(filename, "r") as f:
            lines = f.readlines()

        if lines:
            if lines[0].strip() == "":
                has_text = any(entry.strip() != "" for entry in lines)

                if has_text:
                    print(f"Santarelli Error: the file '{filename}' starts with an empty row. Execution not possible.")
                    sys.exit(1)
                else:
                    open(filename, 'w').close()
            else:
                if not lines[-1].endswith('\n'):
                    add_newline = True

    with open(filename, "a") as f:
        if add_newline:
            f.write("\n")
        f.write(new_entry)


def read_delta_file(file_name):
    """Read an abundance-variation file: {element code: (value, keyword)} for its DELTA, GF and ABS
    rows. An empty dictionary if the file does not exist."""
    extracted_data = {}

    if not os.path.exists(file_name):
        print(f"Warning: file '{file_name}' does not exist.")
        return extracted_data

    with open(file_name, "r") as f:
        for text_line in f:
            clean_text_line = text_line.strip()

            if not clean_text_line:
                continue

            fields = clean_text_line.split()

            if len(fields) >= 3 and fields[0].upper() in ["DELTA", "GF", "ABS"]:
                try:
                    type_line = str(fields[0])
                    code_num = int(fields[1])
                    delta_num = float(fields[2])

                    extracted_data[code_num] = delta_num, type_line

                except ValueError:
                    print(f"Warning: Unable to convert line: '{clean_text_line}' to numbers.")  # FIX: was undefined 'clean_line'

    return extracted_data

def read_abu_var_rows(file_name) -> list[tuple[str, int, list[str]]]:
    """All the rows of an abundance-variation file: (keyword in capitals, element code, values),
    in the order of the file. Rows that cannot be read are skipped; [] if the file does not exist."""
    rows = []
    if not os.path.exists(file_name):
        return rows
    with open(file_name) as f:
        for text_line in f:
            fields = text_line.split()
            if len(fields) >= 3:
                try:
                    rows.append((fields[0].upper(), int(fields[1]), fields[2:]))
                except ValueError:
                    print(f"Warning: Unable to convert line: '{text_line.strip()}' to numbers.")
    return rows


def _signed_code(value: float) -> str:
    """A variation as in the names of the synthetics: 0.29 -> 'p029', -0.1 -> 'm010'.
    FIX: round() instead of int() truncation. abs(0.29)*100 = 28.999999999999996, so int() gave
    '028' and 0.28/0.29 shared the same cache name in synth_out."""
    # sign of the value before rounding, as in the names written by the previous versions
    return f"{'m' if value < 0 else 'p'}{int(round(abs(np.round(value, 2)) * 100)):03}"


def write_name_syn(met, alpha, teff, logg, vt, l1, l2, file_abu_var, type_abu, zcode_str, quantity):
    """Name of a synthetic spectrum in synth_out/, built from all the parameters that define it
    (metallicity, alpha, Teff, logg, vt, wavelength range, abundance variations), so that a
    synthetic computed once is found and reused.

    The rows of the abundance-variation file are encoded as follows (for each element K2 uses the
    last row of a keyword, and so do the names):
      DELTA, ABS  _<El>_p020, _<El>_abs<A x 100> (as before: the names of existing synthetics and
                  of the grids do not change)
      GF          _<El>_gfp020 (NEW: before, as DELTA, so a change of log gf and a change of
                  abundance of the same size had the same name)
      ISOR        _<El>_isor<ratio> (NEW: before, ignored, so the synthetics computed with another
                  isotopic ratio in the file were reused). The ratio of an ISOR line is _ISOR_<El>_<ratio>.
      others      (e.g. ISOF) _x<checksum of the rows> (NEW: before, ignored)
    """
    codes = model_name_codes(teff, logg, vt, met, alpha)
    name_syn = 'a' + codes['met'] + 't' + codes['teff'] + 'g' + codes['logg'] + 'k' + codes['vt'] + '_cl_a' + codes['alpha']

    abundance, gf, isor, others = {}, {}, {}, []
    for key, zcode, values in read_abu_var_rows(file_abu_var):
        try:
            if key in ('DELTA', 'ABS'):
                abundance[zcode] = (float(values[0]), key)
            elif key == 'GF':
                gf[zcode] = float(values[0])
            elif key == 'ISOR':
                isor[zcode] = float(values[0])
            else:
                others.append(' '.join([key, str(zcode)] + values))
        except ValueError:
            print(f"Warning: Unable to convert line: '{key} {zcode} {' '.join(values)}' to numbers.")

    def symbol(zcode):
        return strip_ion(get_element_symbol(zcode, symbol_map))

    for zcode in sorted(set(abundance) | set(gf)):
        if zcode in abundance:
            delta, key = abundance[zcode]
            name_syn += f"_{symbol(zcode)}_abs{int(round(abs(np.round(delta, 2)) * 100)):03}" if key == 'ABS' else f"_{symbol(zcode)}_{_signed_code(delta)}"
        if zcode in gf:
            name_syn += f"_{symbol(zcode)}_gf{_signed_code(gf[zcode])}"

    line_zcode = int(zcode_str) if type_abu == 'ISOR' else None
    for zcode in sorted(isor):
        if zcode != line_zcode:         # the ratio of an ISOR line is written below, as before
            name_syn += f"_{symbol(zcode)}_isor{isor[zcode]:g}".replace('.', 'p')
    if others:
        name_syn += f"_x{zlib.crc32(chr(10).join(others).encode()):08x}"

    if type_abu == 'ISOR':
        name_syn += f"_ISOR_{symbol(zcode_str)}_{quantity:.0f}"

    name_syn += f"_{l1}_{l2}"
    return name_syn


def autok(param1, delta, window):
    """Synthetic spectrum computed by K2 (SYNTHE) for the line of param1, with the abundance of the
    element changed by delta, in a window around the line. A spectrum already in synth_out/ is
    reused. Returns (wavelength, flux), not broadened."""
    teff = int(param1['teff'])
    logg = float(param1['logg'])
    metal = float(param1['met'])
    alpha = int(param1['alpha'])
    vturb = float(param1['vt'])
    resol = int(param1['res'])
    line = float(param1['line'])
    zcode = int(param1['nelem'])
    abu_var = str(param1['abu_var'])
    type_abu = str(param1['tana'])
    abu0 = float(param1['abu0'])

    if cfg.type_norm == 3:
        window = 50

    sep = '  '
    w1 = int(np.floor(line - (window/2)))
    w2 = int(np.ceil(line + (window/2)))

    # FIX: work on a temporary copy of the user's abundance-variation file, so the original
    # is never modified (before, a crash or an exit between add_delta_entry and
    # removing it again left a stray DELTA line in the user's input file).
    abu_var_k2 = abu_var_tmp_name
    if os.path.exists(abu_var):
        shutil.copyfile(abu_var, abu_var_k2)
    else:
        open(abu_var_k2, 'w').close()

    # Add the abundance variation into the temporary abu_var file
    add_delta_entry(type_abu, abu_var_k2, zcode, delta)

    # writing the syn name
    name_syn = write_name_syn(metal, alpha, teff, logg, vturb, w1, w2, abu_var_k2, type_abu, zcode, delta)

    # LANCIA K2
    SYNTH_OUT.mkdir(parents=True, exist_ok=True)

    name_syn = name_syn+'.nb'

    # 1. Define all paths as Path objects at the beginning for clarity.
    output_dir = SYNTH_OUT
    source_file_path = Path(name_syn)
    destination_file_path = output_dir / name_syn

    # 2. Ensure the output directory exists before doing anything else.
    output_dir.mkdir(exist_ok=True)

    # 3. Check if the FINAL file already exists at the destination.
    if destination_file_path.exists():
        if cfg.verbose == 1:
            print("Synthetic spectrum already exists.")
    else:
        written_el = get_element_symbol(zcode, symbol_map)
        if cfg.verbose == 1:    #TO_ADJUST
            print(f"Calling k2: A({written_el}) = {abu0 + delta - float(param1['delta']):.2f}")

        # SCRIVI INPUT.K2 (only when K2 runs). SPEED: trimmed linelist for this window
        with open('input.k2', 'w') as inpk:
            inpk.write('synthe ' + str(teff) + sep + str(logg) + sep + \
                str(metal) + sep + str(alpha) + sep + str(vturb) + \
                ' ' + k2_linelist(w1, w2) + ' ' + abu_var_k2 + sep + str(w1) + sep + str(w2) + \
                sep + str(resol)  + ' 0 ' + name_syn[:-3] + ' 0' + '\n')
            inpk.write('VERBOSE 0\n')
            inpk.write('OUTPUT 0\n')
            inpk.write('CHECKSYN 1\n')

        run_k2()    # SPEED: in-process call (was os.system('k2.py'))

        # 5. Move the file using pathlib's .rename() method, which is robust.
        if source_file_path.exists():
            source_file_path.rename(destination_file_path)
        else:
            # FIX: stop with a clear message (before: a bare FileNotFoundError on the next line)
            raise RuntimeError(f"K2 did not create the synthetic spectrum '{source_file_path.name}'. "
                f"See the K2 messages above (in parallel mode: {WORK_DIR.name}/worker_*.log) and the "
                f"K2 input in {Path.cwd() / 'input.k2'}; common causes: a wrong path in linelist.xkur, "
                f"a missing model atmosphere, or the Kurucz executables not found.")


    xs, ys0 = read_two_columns(SYNTH_OUT / name_syn)    # SPEED: faster reader

    spec_tmp = Spectrum(spectral_axis=xs*u.AA, flux=ys0*u.count)
    xs, ys0 = spec_tmp.spectral_axis, spec_tmp.flux

    # FIX: remove the temporary copy instead of editing the user's file
    if os.path.exists(abu_var_k2):
        os.remove(abu_var_k2)

    return xs, ys0

class K2FormatError(RuntimeError):
    """The EW file of K2 (info_ew.txt) has no slope of the curve of growth: K2 is older than the
    version salvador needs. It stops the run (it is not handled as an error of one line)."""


K2_FORMAT_MESSAGE = 'salvador needs EW file with the COG slope'


def read_info_ew(path: str | Path = 'info_ew.txt') -> tuple[float, float, float, float]:
    """EW [mA], EP [eV], log gf and slope of the curve of growth from the EW file of K2.

    The file has one row: wavelength, EW, EP, log gf, slope (NEW in K2: 'nan' when K2 cannot
    compute the slope, which is returned as 99.999).

    Raises:
        K2FormatError: the row has 4 values (K2 without the slope).
        ValueError: the row cannot be read.
    """
    fields = Path(path).read_text().split()
    if len(fields) == 4:
        raise K2FormatError(K2_FORMAT_MESSAGE)
    if len(fields) != 5:
        raise ValueError(f'{len(fields)} values instead of 5')
    _, ew, ep, loggf, slope = (float(x) for x in fields)
    return ew, ep, loggf, (slope if np.isfinite(slope) else 99.999)


def eqw_k2(param1, delta, window):
    """Equivalent width of the line computed by K2 (eqw; eqwb for ABUF) with the abundance changed by
    delta, and the slope of the curve of growth at that abundance (computed by K2 with A +- 0.1 dex).
    Returns (EW [mA], EP [eV], log gf, slope); 99.99, 99.999, 99.999, 99.999 if K2 gives no result.

    Raises:
        K2FormatError: K2 wrote the EW file without the slope (K2 older than salvador 1.4.0 needs).
    """
    teff = int(param1['teff'])
    logg = float(param1['logg'])
    metal = float(param1['met'])
    alpha = int(param1['alpha'])
    vturb = float(param1['vt'])
    line = float(param1['line'])
    zcode = format(param1['nelem'], ".2f")

    delta = format(delta, ".2f")

    if str(param1['tana']) == 'ABUF':
        first_key = 'eqwb '
    else:
        first_key = 'eqw '

    sep = '  '
    # SPEED: same window as autok, so the trimmed linelist of this line is reused
    win = 50 if cfg.type_norm == 3 else window
    w1 = int(np.floor(line - (win/2)))
    w2 = int(np.ceil(line + (win/2)))
    # SCRIVI INPUT.K2
    inpk = open('input.k2','w')
    inpk.write(first_key + str(teff) + sep + str(logg) + sep + \
        str(metal) + sep + str(alpha) + sep + str(vturb) + \
        ' ' + k2_linelist(w1, w2) + ' ' + str(BASE_DIR / 'delta.tmp') + ' ' + sep + str(line) + \
        sep + zcode  + sep + delta + '\n')
    inpk.write('VERBOSE 0\n')

    inpk.close()

    # LANCIA K2
    # FIX: remove the EW of the previous line, so a silent K2 failure cannot reuse it
    if os.path.exists('info_ew.txt'):
        os.remove('info_ew.txt')
    exit_code = run_k2()    # SPEED: in-process call (was os.system('k2.py'))

    if exit_code == 0:
        try:
            ew_k2, EP, loggf, slope = read_info_ew('info_ew.txt')
            print('EW = %.2f mA' % ew_k2, ('  COG slope = %.3f' % slope) if slope != 99.999 else '  COG slope not available', '\n')
        except (OSError, ValueError) as e:
            print(f'Warning: the EW of K2 could not be read ({type(e).__name__}: {e}): EW set to 99.99')
            ew_k2, EP, loggf, slope = 99.99, 99.999, 99.999, 99.999
    else:
        print('Warning: eqw of k2 did not calculate the EW!!!')
        ew_k2, EP, loggf, slope = 99.99, 99.999, 99.999, 99.999

    return ew_k2, EP, loggf, slope
